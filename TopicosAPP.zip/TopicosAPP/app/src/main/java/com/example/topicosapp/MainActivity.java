package com.example.topicosapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnEjercicio1).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio2.class)));
        findViewById(R.id.btnEjercicio2).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio3.class)));
        findViewById(R.id.btnEjercicio3).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio4.class)));
        findViewById(R.id.btnEjercicio4).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio6.class)));
        findViewById(R.id.btnEjercicio5).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio7.class)));
        findViewById(R.id.btnEjercicio6).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio8.class)));
        findViewById(R.id.btnEjercicio7).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio9.class)));
        findViewById(R.id.btnEjercicio8).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio10.class)));
        findViewById(R.id.btnEjercicio9).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio16.class)));
        findViewById(R.id.btnEjercicio10).setOnClickListener(v -> startActivity(new Intent(this, ActivityEjercicio21.class)));
    }
}
