package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio21 extends AppCompatActivity {

    BotonContador btnA, btnB, btnC;
    Button btnVerPulsaciones, btnReiniciar, btnIniciar, btnRegresar;
    EditText txtInicial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio21);

        LinearLayout contenedor = findViewById(R.id.contenedorBotones);
        btnA = new BotonContador(this);
        btnB = new BotonContador(this);
        btnC = new BotonContador(this);

        btnA.setText("Botón A");
        btnB.setText("Botón B");
        btnC.setText("Botón C");

        contenedor.addView(btnA);
        contenedor.addView(btnB);
        contenedor.addView(btnC);

        txtInicial = findViewById(R.id.txtInicial);
        btnVerPulsaciones = findViewById(R.id.btnVerPulsaciones);
        btnReiniciar = findViewById(R.id.btnReiniciar);
        btnIniciar = findViewById(R.id.btnIniciar);
        btnRegresar = findViewById(R.id.btnRegresar);

        btnA.setOnClickListener(v -> btnA.incrementa());
        btnB.setOnClickListener(v -> btnB.incrementa());
        btnC.setOnClickListener(v -> btnC.aumenta(2)); // según el ejercicio

        btnVerPulsaciones.setOnClickListener(v -> {
            String mensaje = "A: " + btnA.getPulsaciones() + ", B: " + btnB.getPulsaciones() + ", C: " + btnC.getPulsaciones();
            Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
        });

        btnReiniciar.setOnClickListener(v -> {
            btnA.reiniciar();
            btnB.reiniciar();
            btnC.reiniciar();
        });

        btnIniciar.setOnClickListener(v -> {
            try {
                int valor = Integer.parseInt(txtInicial.getText().toString());
                btnA.setPulsaciones(valor);
                btnB.setPulsaciones(valor);
                btnC.setPulsaciones(valor);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Ingresa un número válido", Toast.LENGTH_SHORT).show();
            }
        });

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}