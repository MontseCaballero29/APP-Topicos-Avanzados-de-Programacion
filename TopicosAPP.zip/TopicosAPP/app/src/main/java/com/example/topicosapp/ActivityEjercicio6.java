package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivityEjercicio6 extends AppCompatActivity {

    Spinner cboNumeros;
    Button btnPares, btnImpares, btnVaciar, btnRegresar;
    TextView lblResultado;
    ArrayAdapter<String> adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio6);

        cboNumeros = findViewById(R.id.cboNumeros);
        btnPares = findViewById(R.id.btnPares);
        btnImpares = findViewById(R.id.btnImpares);
        btnVaciar = findViewById(R.id.btnVaciar);
        btnRegresar = findViewById(R.id.btnRegresar);
        lblResultado = findViewById(R.id.lblResultado);

        btnPares.setOnClickListener(v -> {
            ArrayList<String> lista = new ArrayList<>();
            for (int i = 0; i < 10; i += 2) {
                lista.add("Nº " + i);
            }
            actualizarSpinner(lista);
        });

        btnImpares.setOnClickListener(v -> {
            ArrayList<String> lista = new ArrayList<>();
            for (int i = 1; i < 10; i += 2) {
                lista.add("Nº " + i);
            }
            actualizarSpinner(lista);
        });

        btnVaciar.setOnClickListener(v -> {
            actualizarSpinner(new ArrayList<>());
            lblResultado.setText("");
        });

        cboNumeros.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (cboNumeros.getSelectedItem() != null) {
                    lblResultado.setText(cboNumeros.getSelectedItem().toString());
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
                lblResultado.setText("");
            }
        });

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio6.this, MainActivity.class));
            finish();
        });
    }

    private void actualizarSpinner(ArrayList<String> lista) {
        adaptador = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, lista);
        cboNumeros.setAdapter(adaptador);
    }
}