package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio8 extends AppCompatActivity {

    SeekBar slDeslizador;
    TextView lblValor;
    Button btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio8);

        slDeslizador = findViewById(R.id.slDeslizador);
        lblValor = findViewById(R.id.lblValor);
        btnRegresar = findViewById(R.id.btnRegresar);

        slDeslizador.setMax(400); // Máximo - Mínimo = 500 - 100
        slDeslizador.setProgress(300); // 400 - 100 (ajustado a offset 100)

        lblValor.setText("El valor es: " + (slDeslizador.getProgress() + 100));

        slDeslizador.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int valor = progress + 100;
                lblValor.setText("El valor es: " + valor);
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio8.this, MainActivity.class));
            finish();
        });
    }
}