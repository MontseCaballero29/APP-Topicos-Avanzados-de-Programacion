package com.example.topicosapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class ActivityEjercicio4 extends AppCompatActivity {

    Button btnRojo, btnVerde, btnAzul, btnRegresar;
    ConstraintLayout layoutPrincipal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio4);

        btnRojo = findViewById(R.id.btnRojo);
        btnVerde = findViewById(R.id.btnVerde);
        btnAzul = findViewById(R.id.btnAzul);
        btnRegresar = findViewById(R.id.btnRegresar);
        layoutPrincipal = findViewById(R.id.layoutPrincipal);

        btnRojo.setOnClickListener(v -> layoutPrincipal.setBackgroundColor(Color.RED));
        btnVerde.setOnClickListener(v -> layoutPrincipal.setBackgroundColor(Color.GREEN));
        btnAzul.setOnClickListener(v -> layoutPrincipal.setBackgroundColor(Color.BLUE));

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio4.this, MainActivity.class));
            finish();
        });
    }
}