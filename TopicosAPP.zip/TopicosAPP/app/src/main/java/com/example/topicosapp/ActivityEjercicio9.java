package com.example.topicosapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio9 extends AppCompatActivity {

    NumberPicker spinnerValor;
    TextView lblValor;
    Button btnRegresar;

    int[] valores = {0, 2, 4, 6, 8, 10};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio9);

        spinnerValor = findViewById(R.id.spinnerValor);
        lblValor = findViewById(R.id.lblValor);
        btnRegresar = findViewById(R.id.btnRegresar);


        spinnerValor.setMinValue(0);
        spinnerValor.setMaxValue(valores.length - 1);
        spinnerValor.setDisplayedValues(toStringArray(valores));
        spinnerValor.setValue(2); // valor inicial: 4 (índice 2)


        setNumberPickerTextColor(spinnerValor, Color.BLACK);


        lblValor.setText("El valor es: " + valores[spinnerValor.getValue()]);


        spinnerValor.setOnValueChangedListener((picker, oldVal, newVal) -> {
            lblValor.setText("El valor es: " + valores[newVal]);
        });


        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio9.this, MainActivity.class));
            finish();
        });
    }

    private String[] toStringArray(int[] arr) {
        String[] strArray = new String[arr.length];
        for (int i = 0; i < arr.length; i++) {
            strArray[i] = String.valueOf(arr[i]);
        }
        return strArray;
    }


    private void setNumberPickerTextColor(NumberPicker numberPicker, int color) {
        for (int i = 0; i < numberPicker.getChildCount(); i++) {
            View child = numberPicker.getChildAt(i);
            if (child instanceof EditText) {
                try {
                    ((EditText) child).setTextColor(color);
                    ((EditText) child).setTextSize(22);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}