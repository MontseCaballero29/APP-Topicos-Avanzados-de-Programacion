package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio2 extends AppCompatActivity {

    RadioGroup grupoColores;
    RadioButton rbRojo, rbVerde, rbAzul;
    TextView txtResultado;
    Button btnAceptar, btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio2);

        grupoColores = findViewById(R.id.grupoColores);
        rbRojo = findViewById(R.id.rbRojo);
        rbVerde = findViewById(R.id.rbVerde);
        rbAzul = findViewById(R.id.rbAzul);
        txtResultado = findViewById(R.id.txtResultado);
        btnAceptar = findViewById(R.id.btnAceptar);
        btnRegresar = findViewById(R.id.btnRegresar);

        rbRojo.setChecked(true);

        btnAceptar.setOnClickListener(v -> {
            int idSeleccionado = grupoColores.getCheckedRadioButtonId();
            String color = "";
            if (idSeleccionado == R.id.rbRojo) color = "Rojo";
            else if (idSeleccionado == R.id.rbVerde) color = "Verde";
            else if (idSeleccionado == R.id.rbAzul) color = "Azul";
            txtResultado.setText("Color seleccionado: " + color);
        });

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio2.this, MainActivity.class));
            finish();
        });
    }
}
