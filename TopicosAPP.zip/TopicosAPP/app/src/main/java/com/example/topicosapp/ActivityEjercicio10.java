package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivityEjercicio10 extends AppCompatActivity {

    ListView lstNombres;
    TextView lblResultado;
    Button btnCurso1, btnCurso2, btnVaciar, btnRegresar;
    ArrayAdapter<String> adaptador;
    ArrayList<String> listaNombres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio10);

        lstNombres = findViewById(R.id.lstNombres);
        lblResultado = findViewById(R.id.lblResultado);
        btnCurso1 = findViewById(R.id.btnCurso1);
        btnCurso2 = findViewById(R.id.btnCurso2);
        btnVaciar = findViewById(R.id.btnVaciar);
        btnRegresar = findViewById(R.id.btnRegresar);

        listaNombres = new ArrayList<>();

        // Usamos el layout personalizado para que el texto sea negro
        adaptador = new ArrayAdapter<>(this, R.layout.item_lista_nombre, R.id.txtItem, listaNombres);
        lstNombres.setAdapter(adaptador);

        btnCurso1.setOnClickListener(v -> {
            listaNombres.clear();
            listaNombres.add("Juan");
            listaNombres.add("María");
            listaNombres.add("Luis");
            adaptador.notifyDataSetChanged();
        });

        btnCurso2.setOnClickListener(v -> {
            listaNombres.clear();
            listaNombres.add("Ana");
            listaNombres.add("Marta");
            listaNombres.add("Jose");
            adaptador.notifyDataSetChanged();
        });

        btnVaciar.setOnClickListener(v -> {
            listaNombres.clear();
            adaptador.notifyDataSetChanged();
            lblResultado.setText("Selecciona un nombre");
        });

        lstNombres.setOnItemClickListener((parent, view, position, id) -> {
            String seleccionado = listaNombres.get(position);
            lblResultado.setText("Seleccionado: " + seleccionado);
        });

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio10.this, MainActivity.class));
            finish();
        });
    }
}