package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio3 extends AppCompatActivity {

    Spinner spinnerColores;
    TextView txtResultado;
    Button btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio3);

        spinnerColores = findViewById(R.id.spinnerColores);
        txtResultado = findViewById(R.id.txtResultado);
        btnRegresar = findViewById(R.id.btnRegresar);

        String[] colores = {"Rojo", "Verde", "Azul"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, colores);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerColores.setAdapter(adapter);

        spinnerColores.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String seleccionado = parent.getItemAtPosition(position).toString();
                txtResultado.setText("Color seleccionado: " + seleccionado);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                txtResultado.setText("");
            }
        });

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio3.this, MainActivity.class));
            finish();
        });
    }
}
