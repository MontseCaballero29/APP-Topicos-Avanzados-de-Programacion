package com.example.topicosapp;

import android.content.Context;
import androidx.appcompat.widget.AppCompatButton;

public class BotonContador extends AppCompatButton {

    private int pulsaciones;

    public BotonContador(Context context) {
        super(context);
        pulsaciones = 0;
    }

    public void setPulsaciones(int p) {
        pulsaciones = p;
    }

    public int getPulsaciones() {
        return pulsaciones;
    }

    public void incrementa() {
        pulsaciones++;
    }

    public void decrementa() {
        pulsaciones--;
    }

    public void reiniciar() {
        pulsaciones = 0;
    }

    public void aumenta(int c) {
        pulsaciones += c;
    }

    public void disminuye(int c) {
        pulsaciones -= c;
    }
}
