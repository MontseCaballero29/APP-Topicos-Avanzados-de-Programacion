package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio7 extends AppCompatActivity {

    EditText txtPrecioBase;
    ToggleButton tbtnInstalacion, tbtnFormacion, tbtnAlimentacionBD;
    TextView lblTotal, lblPrecioInstalacion, lblPrecioFormacion, lblPrecioAlimentacionBD;
    Button btnCalcular, btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio7);

        txtPrecioBase = findViewById(R.id.txtPrecioBase);
        tbtnInstalacion = findViewById(R.id.tbtnInstalacion);
        tbtnFormacion = findViewById(R.id.tbtnFormacion);
        tbtnAlimentacionBD = findViewById(R.id.tbtnAlimentacionBD);
        lblTotal = findViewById(R.id.lblTotal);
        lblPrecioInstalacion = findViewById(R.id.lblPrecioInstalacion);
        lblPrecioFormacion = findViewById(R.id.lblPrecioFormacion);
        lblPrecioAlimentacionBD = findViewById(R.id.lblPrecioAlimentacionBD);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnRegresar = findViewById(R.id.btnRegresar);
        tbtnInstalacion.setChecked(true);

        btnCalcular.setOnClickListener(v -> {
            double precioBase;
            try {
                precioBase = Double.parseDouble(txtPrecioBase.getText().toString());
            } catch (NumberFormatException e) {
                lblTotal.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                lblTotal.setText("⚠️ Ingresa un número válido");
                return;
            }
            String txtInstalacion = lblPrecioInstalacion.getText().toString().replaceAll("[^0-9.]", "");
            String txtFormacion = lblPrecioFormacion.getText().toString().replaceAll("[^0-9.]", "");
            String txtAlimentacion = lblPrecioAlimentacionBD.getText().toString().replaceAll("[^0-9.]", "");

            double precioInstal = Double.parseDouble(txtInstalacion);
            double precioFor = Double.parseDouble(txtFormacion);
            double precioAli = Double.parseDouble(txtAlimentacion);

            double precioTotal = precioBase;

            if (tbtnInstalacion.isChecked()) precioTotal += precioInstal;
            if (tbtnFormacion.isChecked()) precioTotal += precioFor;
            if (tbtnAlimentacionBD.isChecked()) precioTotal += precioAli;

            lblTotal.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
            lblTotal.setText("Total: $" + precioTotal);
        });

        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio7.this, MainActivity.class));
            finish();
        });
    }
}