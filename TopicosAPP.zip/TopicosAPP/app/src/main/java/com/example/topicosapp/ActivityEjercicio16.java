package com.example.topicosapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio16 extends AppCompatActivity {


    private int coches;

    TextView lblCoches;
    Button btnEntro, btnSalio, btnReiniciar, btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio16);


        coches = 0;


        lblCoches = findViewById(R.id.lblCoches);
        btnEntro = findViewById(R.id.btnEntro);
        btnSalio = findViewById(R.id.btnSalio);
        btnReiniciar = findViewById(R.id.btnReiniciar);
        btnRegresar = findViewById(R.id.btnRegresar);

        lblCoches.setText(String.valueOf(coches));


        btnEntro.setOnClickListener(v -> {
            coches++;
            lblCoches.setText(String.valueOf(coches));
        });


        btnSalio.setOnClickListener(v -> {
            if (coches > 0) {
                coches--;
                lblCoches.setText(String.valueOf(coches));
            }
        });


        btnReiniciar.setOnClickListener(v -> {
            coches = 0;
            lblCoches.setText(String.valueOf(coches));
        });


        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ActivityEjercicio16.this, MainActivity.class));
            finish();
        });
    }
}